---
name: rna-hairpin-6-gccgca
description: Use 'GCCGCA' for 6-nt hairpin loops (winning motif of 4 obs)
metadata:
  type: reference
---

Use 'GCCGCA' for 6-nt hairpin loops (winning motif of 4 obs)

Applies when: {"loop_len": 6}. Design rule: {"motif": "GCCGCA"}. Learned from 4 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-6-gccgca", "kind": "hairpin_motif", "trigger": {"loop_len": 6}, "rule": {"motif": "GCCGCA"}, "description": "Use 'GCCGCA' for 6-nt hairpin loops (winning motif of 4 obs)", "support": 4} -->
