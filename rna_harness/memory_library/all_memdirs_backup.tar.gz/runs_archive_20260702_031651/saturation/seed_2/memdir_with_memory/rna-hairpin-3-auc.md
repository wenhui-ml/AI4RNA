---
name: rna-hairpin-3-auc
description: Use 'AUC' for 3-nt hairpin loops (winning motif of 16 obs)
metadata:
  type: reference
---

Use 'AUC' for 3-nt hairpin loops (winning motif of 16 obs)

Applies when: {"loop_len": 3}. Design rule: {"motif": "AUC"}. Learned from 16 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-3-auc", "kind": "hairpin_motif", "trigger": {"loop_len": 3}, "rule": {"motif": "AUC"}, "description": "Use 'AUC' for 3-nt hairpin loops (winning motif of 16 obs)", "support": 16} -->
