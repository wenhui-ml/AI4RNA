---
name: rna-hairpin-5-cuagu
description: Use 'CUAGU' for 5-nt hairpin loops (winning motif of 12 obs)
metadata:
  type: reference
---

Use 'CUAGU' for 5-nt hairpin loops (winning motif of 12 obs)

Applies when: {"loop_len": 5}. Design rule: {"motif": "CUAGU"}. Learned from 12 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-5-cuagu", "kind": "hairpin_motif", "trigger": {"loop_len": 5}, "rule": {"motif": "CUAGU"}, "description": "Use 'CUAGU' for 5-nt hairpin loops (winning motif of 12 obs)", "support": 12} -->
