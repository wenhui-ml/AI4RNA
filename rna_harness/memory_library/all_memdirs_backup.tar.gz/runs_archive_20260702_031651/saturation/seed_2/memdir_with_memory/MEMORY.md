# RNA design playbook (learned strategies)

- [rna-hairpin-3-auc](rna-hairpin-3-auc.md) — Use 'AUC' for 3-nt hairpin loops (winning motif of 16 obs) (support 16)
- [rna-hairpin-4-ccgg](rna-hairpin-4-ccgg.md) — Use 'CCGG' for 4-nt hairpin loops (winning motif of 44 obs) (support 44)
- [rna-hairpin-5-cuagu](rna-hairpin-5-cuagu.md) — Use 'CUAGU' for 5-nt hairpin loops (winning motif of 12 obs) (support 12)
- [rna-hairpin-6-gccgca](rna-hairpin-6-gccgca.md) — Use 'GCCGCA' for 6-nt hairpin loops (winning motif of 4 obs) (support 4)
- [rna-gc-closing](rna-gc-closing.md) — Close helices with G-C pairs (support 48)
