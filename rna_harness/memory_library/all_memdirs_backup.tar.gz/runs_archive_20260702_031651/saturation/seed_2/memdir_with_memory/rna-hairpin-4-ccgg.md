---
name: rna-hairpin-4-ccgg
description: Use 'CCGG' for 4-nt hairpin loops (winning motif of 44 obs)
metadata:
  type: reference
---

Use 'CCGG' for 4-nt hairpin loops (winning motif of 44 obs)

Applies when: {"loop_len": 4}. Design rule: {"motif": "CCGG"}. Learned from 44 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-4-ccgg", "kind": "hairpin_motif", "trigger": {"loop_len": 4}, "rule": {"motif": "CCGG"}, "description": "Use 'CCGG' for 4-nt hairpin loops (winning motif of 44 obs)", "support": 44} -->
