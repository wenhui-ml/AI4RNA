---
name: rna-hairpin-3-ggc
description: Use 'GGC' for 3-nt hairpin loops (winning motif of 16 obs)
metadata:
  type: reference
---

Use 'GGC' for 3-nt hairpin loops (winning motif of 16 obs)

Applies when: {"loop_len": 3}. Design rule: {"motif": "GGC"}. Learned from 16 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-3-ggc", "kind": "hairpin_motif", "trigger": {"loop_len": 3}, "rule": {"motif": "GGC"}, "description": "Use 'GGC' for 3-nt hairpin loops (winning motif of 16 obs)", "support": 16} -->
