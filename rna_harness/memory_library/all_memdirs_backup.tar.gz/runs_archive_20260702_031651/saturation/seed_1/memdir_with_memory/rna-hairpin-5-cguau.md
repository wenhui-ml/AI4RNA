---
name: rna-hairpin-5-cguau
description: Use 'CGUAU' for 5-nt hairpin loops (winning motif of 12 obs)
metadata:
  type: reference
---

Use 'CGUAU' for 5-nt hairpin loops (winning motif of 12 obs)

Applies when: {"loop_len": 5}. Design rule: {"motif": "CGUAU"}. Learned from 12 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-5-cguau", "kind": "hairpin_motif", "trigger": {"loop_len": 5}, "rule": {"motif": "CGUAU"}, "description": "Use 'CGUAU' for 5-nt hairpin loops (winning motif of 12 obs)", "support": 12} -->
