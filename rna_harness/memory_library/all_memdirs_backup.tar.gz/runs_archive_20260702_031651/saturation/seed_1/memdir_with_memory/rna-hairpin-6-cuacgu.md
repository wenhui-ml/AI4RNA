---
name: rna-hairpin-6-cuacgu
description: Use 'CUACGU' for 6-nt hairpin loops (winning motif of 4 obs)
metadata:
  type: reference
---

Use 'CUACGU' for 6-nt hairpin loops (winning motif of 4 obs)

Applies when: {"loop_len": 6}. Design rule: {"motif": "CUACGU"}. Learned from 4 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-6-cuacgu", "kind": "hairpin_motif", "trigger": {"loop_len": 6}, "rule": {"motif": "CUACGU"}, "description": "Use 'CUACGU' for 6-nt hairpin loops (winning motif of 4 obs)", "support": 4} -->
