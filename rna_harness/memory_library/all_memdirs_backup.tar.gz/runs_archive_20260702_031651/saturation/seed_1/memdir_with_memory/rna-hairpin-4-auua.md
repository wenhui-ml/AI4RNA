---
name: rna-hairpin-4-auua
description: Use 'AUUA' for 4-nt hairpin loops (winning motif of 40 obs)
metadata:
  type: reference
---

Use 'AUUA' for 4-nt hairpin loops (winning motif of 40 obs)

Applies when: {"loop_len": 4}. Design rule: {"motif": "AUUA"}. Learned from 40 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-4-auua", "kind": "hairpin_motif", "trigger": {"loop_len": 4}, "rule": {"motif": "AUUA"}, "description": "Use 'AUUA' for 4-nt hairpin loops (winning motif of 40 obs)", "support": 40} -->
