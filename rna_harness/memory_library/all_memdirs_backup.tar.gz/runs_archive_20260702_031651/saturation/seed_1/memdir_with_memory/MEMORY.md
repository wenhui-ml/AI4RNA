# RNA design playbook (learned strategies)

- [rna-hairpin-3-ggc](rna-hairpin-3-ggc.md) — Use 'GGC' for 3-nt hairpin loops (winning motif of 16 obs) (support 16)
- [rna-hairpin-4-auua](rna-hairpin-4-auua.md) — Use 'AUUA' for 4-nt hairpin loops (winning motif of 40 obs) (support 40)
- [rna-hairpin-5-cguau](rna-hairpin-5-cguau.md) — Use 'CGUAU' for 5-nt hairpin loops (winning motif of 12 obs) (support 12)
- [rna-hairpin-6-cuacgu](rna-hairpin-6-cuacgu.md) — Use 'CUACGU' for 6-nt hairpin loops (winning motif of 4 obs) (support 4)
- [rna-gc-closing](rna-gc-closing.md) — Close helices with G-C pairs (support 47)
