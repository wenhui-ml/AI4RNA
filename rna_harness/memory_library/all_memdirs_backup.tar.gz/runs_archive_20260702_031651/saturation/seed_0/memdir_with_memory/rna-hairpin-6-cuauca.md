---
name: rna-hairpin-6-cuauca
description: Use 'CUAUCA' for 6-nt hairpin loops (winning motif of 4 obs)
metadata:
  type: reference
---

Use 'CUAUCA' for 6-nt hairpin loops (winning motif of 4 obs)

Applies when: {"loop_len": 6}. Design rule: {"motif": "CUAUCA"}. Learned from 4 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-6-cuauca", "kind": "hairpin_motif", "trigger": {"loop_len": 6}, "rule": {"motif": "CUAUCA"}, "description": "Use 'CUAUCA' for 6-nt hairpin loops (winning motif of 4 obs)", "support": 4} -->
