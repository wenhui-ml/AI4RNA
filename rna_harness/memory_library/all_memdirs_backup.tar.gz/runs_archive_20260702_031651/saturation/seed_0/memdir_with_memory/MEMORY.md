# RNA design playbook (learned strategies)

- [rna-hairpin-3-aua](rna-hairpin-3-aua.md) — Use 'AUA' for 3-nt hairpin loops (winning motif of 16 obs) (support 16)
- [rna-hairpin-4-cacc](rna-hairpin-4-cacc.md) — Use 'CACC' for 4-nt hairpin loops (winning motif of 44 obs) (support 44)
- [rna-hairpin-5-ucacc](rna-hairpin-5-ucacc.md) — Use 'UCACC' for 5-nt hairpin loops (winning motif of 12 obs) (support 12)
- [rna-hairpin-6-cuauca](rna-hairpin-6-cuauca.md) — Use 'CUAUCA' for 6-nt hairpin loops (winning motif of 4 obs) (support 4)
- [rna-gc-closing](rna-gc-closing.md) — Close helices with G-C pairs (support 46)
