---
name: rna-hairpin-5-ucacc
description: Use 'UCACC' for 5-nt hairpin loops (winning motif of 12 obs)
metadata:
  type: reference
---

Use 'UCACC' for 5-nt hairpin loops (winning motif of 12 obs)

Applies when: {"loop_len": 5}. Design rule: {"motif": "UCACC"}. Learned from 12 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-5-ucacc", "kind": "hairpin_motif", "trigger": {"loop_len": 5}, "rule": {"motif": "UCACC"}, "description": "Use 'UCACC' for 5-nt hairpin loops (winning motif of 12 obs)", "support": 12} -->
