---
name: rna-hairpin-4-cacc
description: Use 'CACC' for 4-nt hairpin loops (winning motif of 44 obs)
metadata:
  type: reference
---

Use 'CACC' for 4-nt hairpin loops (winning motif of 44 obs)

Applies when: {"loop_len": 4}. Design rule: {"motif": "CACC"}. Learned from 44 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-4-cacc", "kind": "hairpin_motif", "trigger": {"loop_len": 4}, "rule": {"motif": "CACC"}, "description": "Use 'CACC' for 4-nt hairpin loops (winning motif of 44 obs)", "support": 44} -->
