# RNA design playbook (learned strategies)

- [rna-hairpin-3-aua](rna-hairpin-3-aua.md) — Use 'AUA' for 3-nt hairpin loops (winning motif of 6 obs) (support 6)
- [rna-hairpin-4-acaa](rna-hairpin-4-acaa.md) — Use 'ACAA' for 4-nt hairpin loops (winning motif of 13 obs) (support 13)
- [rna-hairpin-5-ccacc](rna-hairpin-5-ccacc.md) — Use 'CCACC' for 5-nt hairpin loops (winning motif of 9 obs) (support 9)
- [rna-hairpin-6-cuauca](rna-hairpin-6-cuauca.md) — Use 'CUAUCA' for 6-nt hairpin loops (winning motif of 3 obs) (support 3)
- [rna-gc-closing](rna-gc-closing.md) — Close helices with G-C pairs (support 24)
