---
name: rna-hairpin-5-ccacc
description: Use 'CCACC' for 5-nt hairpin loops (winning motif of 9 obs)
metadata:
  type: reference
---

Use 'CCACC' for 5-nt hairpin loops (winning motif of 9 obs)

Applies when: {"loop_len": 5}. Design rule: {"motif": "CCACC"}. Learned from 9 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-5-ccacc", "kind": "hairpin_motif", "trigger": {"loop_len": 5}, "rule": {"motif": "CCACC"}, "description": "Use 'CCACC' for 5-nt hairpin loops (winning motif of 9 obs)", "support": 9} -->
