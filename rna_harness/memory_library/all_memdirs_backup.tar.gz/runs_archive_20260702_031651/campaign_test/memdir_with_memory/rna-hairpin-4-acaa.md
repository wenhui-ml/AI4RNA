---
name: rna-hairpin-4-acaa
description: Use 'ACAA' for 4-nt hairpin loops (winning motif of 13 obs)
metadata:
  type: reference
---

Use 'ACAA' for 4-nt hairpin loops (winning motif of 13 obs)

Applies when: {"loop_len": 4}. Design rule: {"motif": "ACAA"}. Learned from 13 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-4-acaa", "kind": "hairpin_motif", "trigger": {"loop_len": 4}, "rule": {"motif": "ACAA"}, "description": "Use 'ACAA' for 4-nt hairpin loops (winning motif of 13 obs)", "support": 13} -->
