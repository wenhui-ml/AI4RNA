---
name: rna-hairpin-3-aaa
description: Use 'AAA' for 3-nt hairpin loops (winning motif of 2 obs)
metadata:
  type: reference
---

Use 'AAA' for 3-nt hairpin loops (winning motif of 2 obs)

Applies when: {"loop_len": 3}. Design rule: {"motif": "AAA"}. Learned from 2 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-3-aaa", "kind": "hairpin_motif", "trigger": {"loop_len": 3}, "rule": {"motif": "AAA"}, "description": "Use 'AAA' for 3-nt hairpin loops (winning motif of 2 obs)", "support": 2} -->
