# RNA design playbook (learned strategies)

- [rna-hairpin-3-aaa](rna-hairpin-3-aaa.md) — Use 'AAA' for 3-nt hairpin loops (winning motif of 2 obs) (support 2)
- [rna-hairpin-4-gaaa](rna-hairpin-4-gaaa.md) — Use 'GAAA' for 4-nt hairpin loops (winning motif of 4 obs) (support 4)
- [rna-hairpin-6-aaaaaa](rna-hairpin-6-aaaaaa.md) — Use 'AAAAAA' for 6-nt hairpin loops (winning motif of 2 obs) (support 2)
- [rna-gc-closing](rna-gc-closing.md) — Close helices with G-C pairs (support 6)
