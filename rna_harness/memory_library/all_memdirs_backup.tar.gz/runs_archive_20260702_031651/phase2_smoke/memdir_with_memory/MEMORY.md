# RNA design playbook (learned strategies)

- [rna-hairpin-3-aaa](rna-hairpin-3-aaa.md) — Use 'AAA' for 3-nt hairpin loops (winner: 1/1 obs) (support 1)
- [rna-hairpin-6-aaaaaa](rna-hairpin-6-aaaaaa.md) — Use 'AAAAAA' for 6-nt hairpin loops (winner: 1/1 obs) (support 1)
- [rna-gc-closing](rna-gc-closing.md) — Close helices with G-C pairs (support 2)
