---
name: rna-hairpin-4-cccc
description: (permuted/wrong) use CCCC for 4-nt loops
metadata:
  type: reference
---

(permuted/wrong) use CCCC for 4-nt loops

Applies when: {"loop_len": 4}. Design rule: {"motif": "CCCC"}. Learned from 1 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-4-cccc", "kind": "hairpin_motif", "trigger": {"loop_len": 4}, "rule": {"motif": "CCCC"}, "description": "(permuted/wrong) use CCCC for 4-nt loops", "support": 1} -->
