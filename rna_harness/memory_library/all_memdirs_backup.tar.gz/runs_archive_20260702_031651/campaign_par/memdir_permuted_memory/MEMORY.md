# RNA design playbook (learned strategies)

- [rna-hairpin-4-cccc](rna-hairpin-4-cccc.md) — (permuted/wrong) use CCCC for 4-nt loops (support 1)
