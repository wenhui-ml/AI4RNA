---
name: rna-hairpin-4-gucc
description: Use 'GUCC' for 4-nt hairpin loops (winning motif of 13 obs)
metadata:
  type: reference
---

Use 'GUCC' for 4-nt hairpin loops (winning motif of 13 obs)

Applies when: {"loop_len": 4}. Design rule: {"motif": "GUCC"}. Learned from 13 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-4-gucc", "kind": "hairpin_motif", "trigger": {"loop_len": 4}, "rule": {"motif": "GUCC"}, "description": "Use 'GUCC' for 4-nt hairpin loops (winning motif of 13 obs)", "support": 13} -->
