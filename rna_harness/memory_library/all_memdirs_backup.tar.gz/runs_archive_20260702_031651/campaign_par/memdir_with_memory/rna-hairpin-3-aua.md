---
name: rna-hairpin-3-aua
description: Use 'AUA' for 3-nt hairpin loops (winning motif of 6 obs)
metadata:
  type: reference
---

Use 'AUA' for 3-nt hairpin loops (winning motif of 6 obs)

Applies when: {"loop_len": 3}. Design rule: {"motif": "AUA"}. Learned from 6 solved case(s).

<!-- rna_strategy: {"name": "rna-hairpin-3-aua", "kind": "hairpin_motif", "trigger": {"loop_len": 3}, "rule": {"motif": "AUA"}, "description": "Use 'AUA' for 3-nt hairpin loops (winning motif of 6 obs)", "support": 6} -->
