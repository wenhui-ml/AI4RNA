Supplementary material for "Solved Is a Choice of Verifier, Not a Fact" (AAAI-27 anonymous submission).
Contents:
  verifier_economics_supp.pdf      - technical appendix (proofs, RNA/SAT defs, cost model, full RLVR config)
  ReproducibilityChecklist.pdf     - AAAI reproducibility checklist
  code/                            - verifier arms, GRPO reward plugin, data prep, eval/aggregate/figure scripts
Paths in code are anonymized (<REPO>/<MODELS>/<PATH>). Model weights and datasets are the public
Qwen2.5 / Llama-3.1 / NuminaMath / EteRNA100 / HumanEval+ releases cited in the paper.
