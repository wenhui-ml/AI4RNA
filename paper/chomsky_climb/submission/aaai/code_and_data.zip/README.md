# Code and data supplement

## What is here

- `rna_harness/runs/cc_ascent/` -- every logged run behind every number in the paper (per-target JSON for
  all sweeps), the analysis scripts that reduce them, their committed `.txt` outputs, and the frozen
  agent-written operator sources.
- `rna_harness/**.py` -- the harness itself, as the transitive closure of what the above imports. This is
  computed by `paper/chomsky_climb/submission/collect_code.py`, not curated by hand.
- `paper/chomsky_climb/make_figs.py` -- regenerates the data figures from the same committed outputs.

## Re-running

Analysis scripts read the committed JSON and need no oracle binaries:

    cd <extracted>
    python rna_harness/runs/cc_ascent/arep_matched.py      # the positive control, 0.293 vs 0.095
    python rna_harness/runs/cc_ascent/family_stats.py      # the unbounded family, +0.316
    python rna_harness/runs/cc_ascent/dom_stats.py         # the ensemble-gap transplant, exactly zero

Re-executing the *sweeps* additionally needs the four oracles; see `ENVIRONMENT.md` and App. F.

## What is deliberately not reproducible

The **invention step**. The six operators were written by frontier models behind a routed provider alias with
no version hash, so a re-run may not query the same weights. No number in the paper depends on it: every
measurement re-executes the frozen operator source shipped here rather than re-querying a model. The claim
"an agent can invent such an operator" does depend on it, and Sec. 6.2(v) says so.
