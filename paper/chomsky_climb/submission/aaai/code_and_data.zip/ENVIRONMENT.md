# Environment

Measured on the host that produced the paper's numbers.

    python        3.13.13
    ViennaRNA     2.7.2
    numpy         2.5.1
    scipy         1.18.0
    matplotlib    3.11.1

Oracles live in three conda environments because RNAstructure and pKiss cannot share one; App. F pins the
configuration of each, and `DATAPATH` must point at the RNAstructure data tables.

    env rna      ViennaRNA ($\Omega_{cf}$: Turner-2004 MFE at 37 C, no timeout)
    env pk       pKiss     (`pkiss mfe`, 60 s)
    env rnastr   ProbKnot  (MEA over the partition ensemble, 60 s)
                 ShapeKnots (MFE-based, run de novo with no SHAPE data, 120 s)

Compute: one 256-core host, target-level parallelism at NWORKERS=60. The sweep suite is search-only and
incurs no model-inference cost apart from the invention agent.
