# Environment

## The environments that produced the paper's numbers

Every oracle and every design operator ran under **Python 3.10.20**, each oracle in its own pinned conda
environment because RNAstructure and pKiss cannot share one. App. F pins the configuration of each, and
`DATAPATH` must point at the RNAstructure data tables.

    env rna      Python 3.10.20   ViennaRNA 2.7.2   ($\Omega_{cf}$: Turner-2004 MFE at 37 C, no timeout)
    env pk       Python 3.10.20   pKiss 2.3.0       (`pkiss mfe`, 60 s; bellmans-gapc 2024.01.12, bioconda)
    env rnastr   Python 3.10.20   RNAstructure 6.6  (ProbKnot: MEA over the partition ensemble, 60 s)
                                                   (ShapeKnots: MFE-based, de novo with no SHAPE data, 120 s)

## The comparison baseline

DesiRNA publishes no release tag, so it is pinned three ways:

    repository    https://github.com/fryzjergda/DesiRNA
    commit        bdb4908  ("Update test_DesiRNA.yml", 2024-06-06, upstream main)
    version       in-file string "Version: 11.2023" (DesiRNA.py:20)
    DOI           10.1093/nar/gkae1306   (preprint 10.1101/2023.06.04.543636)

Invoked by `rna_harness/generators/desirna.py` as, with DESIRNA_ARGS unset:

    DesiRNA.py -f input.txt -p 2004 -R 10 -t 120 -r 20 -seed <seed>          # hard-killed at 240 s

`-p 2004` is not a default and is load-bearing: DesiRNA optimizes Turner 1999 out of the box, our oracle is
Turner 2004, and sequences optimal under the former come back 1-2 base pairs off under the latter. Every
sequence it returns is re-folded under our own oracle before it counts, and re-checked under pKiss on crossing
targets. The solver never certifies itself.

## The host that assembled this supplement

Reported for completeness only. This is whichever machine ran `build.sh`, which need not be -- and generally
is not -- a machine that can run the oracles. Do not read these as the run environment; the block above is the
run environment.

    python        3.10.20
    numpy         2.2.6
    scipy         1.15.2
    matplotlib    3.10.9
    ViennaRNA     2.7.2

## Compute

One 256-core host, target-level parallelism at NWORKERS=60. The sweep suite is search-only and incurs no
model-inference cost apart from the invention agent (App. E), a few dollars of GLM-5.2.
