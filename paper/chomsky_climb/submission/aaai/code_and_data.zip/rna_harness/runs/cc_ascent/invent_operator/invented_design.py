# Agent-invented (glm-5.2, round 2, train 12/16); held-out: pKiss&ProbKnot 35/60, panel-unanimous 9/60.
# Written autonomously from primitives+oracles (no recipe, no external solver).

def design(target, seed=0):
    random.seed(seed)
    n = len(target)
    T = target_pairs(target)
    if T is None:
        T = set()
    T = set(tuple(p) for p in T)

    def safe_fold(f, seq):
        res = f(seq)
        if res is None:
            return set()
        return set(tuple(p) for p in res)

    def get_nested_pairs(pairs):
        nested = set()
        plist = sorted(pairs)
        for (i, j) in plist:
            crosses = False
            for (k, l) in plist:
                if (i, j) != (k, l):
                    if (i < k < j < l) or (k < i < l < j):
                        crosses = True
                        break
            if not crosses:
                nested.add((i, j))
        return nested

    nested_pairs = get_nested_pairs(T)
    crossing_pairs = T - nested_pairs

    nested_db = ['.'] * n
    for (i, j) in nested_pairs:
        nested_db[i] = '('
        nested_db[j] = ')'
    nested_db = ''.join(nested_db)

    def enforce_pairs(seq, pairs):
        seq = list(seq)
        for (i, j) in pairs:
            a, b = random.choice([('A', 'U'), ('U', 'A'), ('G', 'C'), ('C', 'G')])
            seq[i] = a
            seq[j] = b
        return ''.join(seq)

    def cost(seq):
        P1 = safe_fold(fold_pkiss_pairs, seq)
        P2 = safe_fold(fold_probknot_pairs, seq)
        c = len(T - P1) + len(T - P2) + len(P1 - T) * 2 + len(P2 - T) * 2
        return c

    def greedy_step(seq, current_cost):
        best_seq = seq
        best_cost = current_cost
        P1 = safe_fold(fold_pkiss_pairs, seq)
        P2 = safe_fold(fold_probknot_pairs, seq)
        error_pairs = (T - P1) | (T - P2) | (P1 - T) | (P2 - T)
        error_positions = set()
        for i, j in error_pairs:
            error_positions.add(i)
            error_positions.add(j)
        for pos in error_positions:
            partner = None
            for (i, j) in T:
                if i == pos:
                    partner = j
                    break
                if j == pos:
                    partner = i
                    break
            current_base = seq[pos]
            choices = ['A', 'U', 'G', 'C']
            choices.remove(current_base)
            for new_base in choices:
                new_seq = list(seq)
                new_seq[pos] = new_base
                if partner is not None:
                    new_seq[partner] = COMP[new_base]
                new_seq = ''.join(new_seq)
                c = cost(new_seq)
                if c < best_cost:
                    best_cost = c
                    best_seq = new_seq
        return best_seq, best_cost

    best_seq = None
    best_cost = float('inf')

    max_restarts = 15
    max_iter = 3000

    for restart in range(max_restarts):
        if restart == 0:
            seq = enforce_pairs('A' * n, T)
        elif restart == 1:
            seq = enforce_pairs(rand_seq(n, seed + restart), T)
        else:
            base_seq = inverse_fold_cf(nested_db, seed + restart)
            if base_seq is None:
                base_seq = rand_seq(n, seed + restart)
            seq = enforce_pairs(base_seq, T)

        current_seq = seq
        current_cost = cost(current_seq)
        if current_cost == 0:
            return current_seq

        T_temp = 2.0
        cooling = 0.997
        no_improve = 0

        for it in range(max_iter):
            if it % 100 == 0 and current_cost <= 6:
                current_seq, current_cost = greedy_step(current_seq, current_cost)
                if current_cost == 0:
                    return current_seq

            P1 = safe_fold(fold_pkiss_pairs, current_seq)
            P2 = safe_fold(fold_probknot_pairs, current_seq)
            error_pairs = (T - P1) | (T - P2) | (P1 - T) | (P2 - T)
            error_positions = set()
            for i, j in error_pairs:
                error_positions.add(i)
                error_positions.add(j)

            new_seq = list(current_seq)
            if error_positions and random.random() < 0.85:
                pos = random.choice(list(error_positions))
            else:
                pos = random.randint(0, n - 1)

            partner = None
            for (i, j) in T:
                if i == pos:
                    partner = j
                    break
                if j == pos:
                    partner = i
                    break

            if partner is not None:
                current = new_seq[pos]
                choices = ['A', 'U', 'G', 'C']
                choices.remove(current)
                new_base = random.choice(choices)
                new_seq[pos] = new_base
                new_seq[partner] = COMP[new_base]
            else:
                current = new_seq[pos]
                choices = ['A', 'U', 'G', 'C']
                choices.remove(current)
                new_seq[pos] = random.choice(choices)

            new_seq = ''.join(new_seq)
            new_cost = cost(new_seq)

            if new_cost < current_cost:
                current_seq = new_seq
                current_cost = new_cost
                no_improve = 0
            elif new_cost == current_cost:
                if random.random() < 0.3:
                    current_seq = new_seq
                    current_cost = new_cost
                no_improve += 1
            else:
                delta = new_cost - current_cost
                if random.random() < math.exp(-delta / max(T_temp, 0.01)):
                    current_seq = new_seq
                    current_cost = new_cost
                no_improve += 1

            T_temp *= cooling
            if current_cost == 0:
                return current_seq
            if no_improve > 200:
                T_temp = max(T_temp, 1.5)
                no_improve = 0

        if current_cost < best_cost:
            best_cost = current_cost
            best_seq = current_seq

    # Final greedy polish
    if best_seq is not None and best_cost > 0:
        for _ in range(50):
            best_seq, best_cost = greedy_step(best_seq, best_cost)
            if best_cost == 0:
                break
    return best_seq if best_seq is not None else 'A' * n
