#!/usr/bin/env python3
"""Statistical separation of the panel-optimizing operator's panel-unanimous ascent
from the single-oracle gaming baseline (chomsky_climb positive side).

Reads the per-target panel adjudications (pKiss AND ProbKnot AND ShapeKnots -> unanimous)
for panel_auto (3 seeds) and the autonomous gamer (seed 0), both autonomous and on the SAME
60 held-out Pseudobase crossing targets. Reports:
  (1) per-seed + pooled panel-unanimous rates with percentile-bootstrap 95% CIs;
  (2) paired McNemar exact test (seed 0): panel_auto vs gamer on identical targets;
  (3) exact one-sided binomial of each panel_auto seed / pool vs the gamer's fixed 1/60 rate.
No live episodes: pure offline re-use of saved adjudications.
"""
import json, math, os, random

random.seed(20260723)
HERE = os.path.dirname(os.path.abspath(__file__))
IDS = [f"pseudobase:{i}" for i in range(60)]          # the frozen 60-target held-out pool
GAMER_BASELINE = 1 / 60                                 # single-oracle gamer, panel-unanimous

def uni_set(path):
    """Panel-unanimous id set. Handles both panel_*.json (rows have 'unanimous') and the parallel
    sweep.py format (rows have arms.panel_auto.panel.unanimous)."""
    d = json.load(open(os.path.join(HERE, path)))
    ids = set()
    for r in d["rows"]:
        if "arms" in r:
            u = ((r["arms"].get("panel_auto") or {}).get("panel") or {}).get("unanimous")
        else:
            u = r.get("unanimous")
        if u:
            ids.add(r["id"])
    return ids

def vec(s):  # binary unanimous vector over the 60 held-out ids
    return [1 if i in s else 0 for i in IDS]

def boot_ci(v, B=20000, lo=2.5, hi=97.5):
    n = len(v); rates = []
    for _ in range(B):
        rates.append(sum(v[random.randrange(n)] for _ in range(n)) / n)
    rates.sort()
    return rates[int(lo/100*B)], rates[int(hi/100*B)]

def cluster_boot_ci(seed_vecs, B=20000, lo=2.5, hi=97.5):
    """Target-level cluster bootstrap: the SAME 60 targets recur across seeds, so the pooled
    5x60 outcomes are NOT independent. Resample the 60 TARGETS with replacement; each drawn target
    contributes all its per-seed outcomes as one cluster. This respects target-level correlation and
    yields an honestly wider CI than the naive i.i.d. pooled bootstrap."""
    mat = list(zip(*seed_vecs))     # mat[t] = tuple of the target t's outcome under each seed
    n = len(mat); rates = []
    for _ in range(B):
        num = den = 0
        for _ in range(n):
            cl = mat[random.randrange(n)]
            num += sum(cl); den += len(cl)
        rates.append(num / den)
    rates.sort()
    return rates[int(lo/100*B)], rates[int(hi/100*B)]

def binom_tail_ge(k, n, p):   # P(X >= k) for X~Bin(n,p), exact one-sided
    return sum(math.comb(n, j) * p**j * (1-p)**(n-j) for j in range(k, n+1))

def mcnemar_exact(b, c):      # two-sided exact McNemar on discordant counts b,c
    n = b + c
    if n == 0: return 1.0
    m = min(b, c)
    p = 2 * sum(math.comb(n, k) * 0.5**n for k in range(0, m+1))
    return min(p, 1.0)

gamer = uni_set("generous/panel_autonomous.json")
seeds = {
    "panel_auto seed0": uni_set("panel_auto/panel_panel_auto.json"),
    "panel_auto seed1": uni_set("seed1/panel/panel_panel_auto.json"),
    "panel_auto seed2": uni_set("seed2/panel/panel_panel_auto.json"),
    "panel_auto seed3": uni_set("seed3/sweep.json"),
    "panel_auto seed4": uni_set("seed4/sweep.json"),
}

print(f"held-out pool n=60 ; gamer panel-unanimous = {len(gamer)}/60 = {len(gamer)/60:.4f}  ids={sorted(gamer)}\n")

print("(1) panel_auto panel-unanimous rate + percentile-bootstrap 95% CI (B=20000):")
pooled = []; seed_vecs = []
for name, s in seeds.items():
    v = vec(s); pooled += v; seed_vecs.append(v)
    lo, hi = boot_ci(v)
    clears = "CLEARS" if lo > GAMER_BASELINE else "does NOT clear"
    print(f"  {name}: {len(s):2d}/60 = {len(s)/60:.4f}  95% CI [{lo:.4f}, {hi:.4f}]  ({clears} gamer {GAMER_BASELINE:.4f})")
# Naive i.i.d. pooled bootstrap (reported for contrast only -- treats 5x60 as independent; INVALID)
lo_n, hi_n = boot_ci(pooled)
# Correct: target-level cluster bootstrap (resamples the 60 recurring targets)
lo_c, hi_c = cluster_boot_ci(seed_vecs)
clears = "CLEARS" if lo_c > GAMER_BASELINE else "does NOT clear"
print(f"  POOLED 5 seeds: {sum(pooled)}/{len(pooled)} = {sum(pooled)/len(pooled):.4f}")
print(f"     naive i.i.d. bootstrap CI [{lo_n:.4f}, {hi_n:.4f}]  (INVALID: ignores target clustering)")
print(f"     CLUSTER bootstrap CI [{lo_c:.4f}, {hi_c:.4f}]  ({clears} gamer {GAMER_BASELINE:.4f})  <- correct")

print("\n(2) paired McNemar exact (SAME 60 targets), panel_auto seedX vs gamer:")
nsig = 0
for name, s in seeds.items():
    b = len(s - gamer)          # panel_auto unanimous, gamer not
    c = len(gamer - s)          # gamer unanimous, panel_auto not
    p = mcnemar_exact(b, c)
    sig = " *SIG@0.05" + ("(survives Bonferroni x5)" if p < 0.05/5 else "(NOT after Bonferroni x5)") if p < 0.05 else ""
    nsig += int(p < 0.05)
    print(f"  {name}: b(only panel_auto)={b}  c(only gamer)={c}  discordant={b+c}  McNemar exact p={p:.4f}{sig}")
print(f"  -> {nsig}/5 seeds individually significant at 0.05; the paired McNemar (same targets) is the valid per-seed test.")

print("\n(3) per-seed exact one-sided binomial vs gamer's fixed rate p0=1/60 (60 independent targets/seed = VALID):")
for name, s in seeds.items():
    k = len(s); p = binom_tail_ge(k, 60, GAMER_BASELINE)
    print(f"  {name}: P(X>={k}/60 | p0=1/60) = {p:.2e}")
kk = sum(pooled); nn = len(pooled)
print(f"\n  [NOT USED] naive pooled binomial P(X>={kk}/{nn} | p0=1/60) = {binom_tail_ge(kk, nn, GAMER_BASELINE):.2e}")
print( "  -> INVALID as a p-value: the 5x60 pooled trials are clustered (same 60 targets recur), not 300")
print( "     independent Bernoulli draws. We rely on the per-seed binomials/McNemar + the cluster-bootstrap CI above.")


# ---- (4) matched-seed paired difference: gamer vs panel operator on the SAME 5 seeds + targets ----
# Absorbs the 2nd external review (new-6): run the gamer on matched seeds and report the paired
# Delta = p_panel - p_gamer with a target-level cluster bootstrap, instead of treating 1/60 as a fixed baseline.
def _uni(rows, arm=None):
    d = {}
    for r in rows:
        u = (((r.get("arms", {}) or {}).get(arm) or {}).get("panel") or {}).get("unanimous") if arm else r.get("unanimous")
        d[r["id"]] = 1 if u else 0
    return d


def matched_seed_paired(B=20000):
    PA = {0: _uni(json.load(open(os.path.join(HERE, "panel_auto/panel_panel_auto.json")))["rows"]),
          1: _uni(json.load(open(os.path.join(HERE, "seed1/panel/panel_panel_auto.json")))["rows"]),
          2: _uni(json.load(open(os.path.join(HERE, "seed2/panel/panel_panel_auto.json")))["rows"]),
          3: _uni(json.load(open(os.path.join(HERE, "seed3/sweep.json")))["rows"], "panel_auto"),
          4: _uni(json.load(open(os.path.join(HERE, "seed4/sweep.json")))["rows"], "panel_auto")}
    GA = {s: _uni(json.load(open(os.path.join(HERE, f"gamer_s{s}/sweep.json")))["rows"], "autonomous") for s in range(5)}
    print("\n(4) MATCHED-SEED paired difference (gamer vs panel operator, same seeds+targets):")
    per_t = {t: [] for t in IDS}
    for s in range(5):
        pc = sum(PA[s].get(t, 0) for t in IDS); gc = sum(GA[s].get(t, 0) for t in IDS)
        b = sum(1 for t in IDS if PA[s].get(t, 0) and not GA[s].get(t, 0))
        c = sum(1 for t in IDS if GA[s].get(t, 0) and not PA[s].get(t, 0))
        print(f"  seed {s}: gamer={gc}/60  panel={pc}/60  McNemar b={b},c={c},p={mcnemar_exact(b,c):.4f}")
        for t in IDS:
            per_t[t].append(PA[s].get(t, 0) - GA[s].get(t, 0))
    diffs = [d for v in per_t.values() for d in v]; mean_d = sum(diffs) / len(diffs)
    rates = []
    for _ in range(B):
        tot = n = 0
        for _ in range(len(IDS)):
            v = per_t[IDS[random.randrange(len(IDS))]]; tot += sum(v); n += len(v)
        rates.append(tot / n)
    rates.sort()
    lo, hi = rates[int(0.025 * B)], rates[int(0.975 * B)]
    gp = sum(sum(GA[s].get(t, 0) for t in IDS) for s in range(5))
    pp = sum(sum(PA[s].get(t, 0) for t in IDS) for s in range(5))
    print(f"  pooled: gamer={gp}/300  panel={pp}/300  Delta=p_panel-p_gamer={mean_d:+.4f}  "
          f"cluster-boot 95% CI [{lo:+.4f},{hi:+.4f}]")


# ---- (5) TWO-WAY bootstrap: resample BOTH targets and seeds (reviewer R4 statistics item 3) ----
# The cluster bootstrap of (4) resamples targets but treats the 5 seeds as fixed, so its CI is conditional on
# the observed seeds and understates algorithmic variance. A hierarchical (crossed random-effects) model is the
# principled fix but 5 seeds cannot stabilise a seed-variance component; the two-way bootstrap is the
# distribution-free stand-in: independently resample the 60 targets AND the 5 seeds with replacement, so both
# sources of sampling error enter the interval. Reported alongside the target-only CI, never instead of it.
def two_way_bootstrap(B=20000):
    PA = {0: _uni(json.load(open(os.path.join(HERE, "panel_auto/panel_panel_auto.json")))["rows"]),
          1: _uni(json.load(open(os.path.join(HERE, "seed1/panel/panel_panel_auto.json")))["rows"]),
          2: _uni(json.load(open(os.path.join(HERE, "seed2/panel/panel_panel_auto.json")))["rows"]),
          3: _uni(json.load(open(os.path.join(HERE, "seed3/sweep.json")))["rows"], "panel_auto"),
          4: _uni(json.load(open(os.path.join(HERE, "seed4/sweep.json")))["rows"], "panel_auto")}
    GA = {s: _uni(json.load(open(os.path.join(HERE, f"gamer_s{s}/sweep.json")))["rows"], "autonomous")
          for s in range(5)}
    S, T = list(range(5)), IDS
    D = {(s, t): PA[s].get(t, 0) - GA[s].get(t, 0) for s in S for t in T}
    obs = sum(D.values()) / len(D)

    def resample(seeds_too):
        ss = [S[random.randrange(len(S))] for _ in range(len(S))] if seeds_too else S
        ts = [T[random.randrange(len(T))] for _ in range(len(T))]
        return sum(D[(s, t)] for s in ss for t in ts) / (len(ss) * len(ts))

    out = {}
    for label, seeds_too in (("target-only", False), ("two-way (targets+seeds)", True)):
        r = sorted(resample(seeds_too) for _ in range(B))
        out[label] = (r[int(0.025 * B)], r[int(0.975 * B)])
    print("\n(5) bootstrap CIs for the paired difference Delta = p_panel - p_gamer (n=60 pool, 5 seeds):")
    print(f"  observed Delta = {obs:+.4f}")
    for label, (lo, hi) in out.items():
        clears = "clears 0" if lo > 0 else "does NOT clear 0"
        print(f"  {label:24s} 95% CI [{lo:+.4f},{hi:+.4f}]  ({clears})")
    # seed-level spread of the per-seed difference: the quantity the target-only CI conditions away
    per_seed = [sum(D[(s, t)] for t in T) / len(T) for s in S]
    mean = sum(per_seed) / len(per_seed)
    sd = (sum((x - mean) ** 2 for x in per_seed) / (len(per_seed) - 1)) ** 0.5
    print(f"  per-seed Delta: {['%+.4f' % x for x in per_seed]}  mean {mean:+.4f}  sd {sd:.4f}  "
          f"(sd/sqrt(5) = {sd/5**0.5:.4f})")


# ---- (6) INFLUENCE + CONCENTRATION (reviewer R5 §5.4) ----
# r_mix is a low-base-rate conjunction (~5/60), so one or two targets can move the effect size materially.
# Report (a) leave-one-target-out recomputation of the paired Delta, (b) how concentrated the successes are
# across targets and seeds, and (c) whether they sit on structurally easy (low-crossing-count) targets.
def influence_and_concentration():
    PA = {0: _uni(json.load(open(os.path.join(HERE, "panel_auto/panel_panel_auto.json")))["rows"]),
          1: _uni(json.load(open(os.path.join(HERE, "seed1/panel/panel_panel_auto.json")))["rows"]),
          2: _uni(json.load(open(os.path.join(HERE, "seed2/panel/panel_panel_auto.json")))["rows"]),
          3: _uni(json.load(open(os.path.join(HERE, "seed3/sweep.json")))["rows"], "panel_auto"),
          4: _uni(json.load(open(os.path.join(HERE, "seed4/sweep.json")))["rows"], "panel_auto")}
    GA = {s: _uni(json.load(open(os.path.join(HERE, f"gamer_s{s}/sweep.json")))["rows"], "autonomous")
          for s in range(5)}
    S = list(range(5))
    D = {(s, t): PA[s].get(t, 0) - GA[s].get(t, 0) for s in S for t in IDS}
    full = sum(D.values()) / len(D)

    print("\n(6) influence and concentration of the r_mix successes (n=60 pool, 5 seeds):")
    loo = []
    for t in IDS:
        kept = [D[(s, u)] for s in S for u in IDS if u != t]
        loo.append((sum(kept) / len(kept), t))
    loo.sort()
    print(f"  full Delta {full:+.4f}; leave-one-target-out range "
          f"[{loo[0][0]:+.4f} (drop {loo[0][1]}), {loo[-1][0]:+.4f} (drop {loo[-1][1]})]")
    print(f"  most influential single target: {loo[0][1]} (dropping it moves Delta by {loo[0][0]-full:+.4f})")

    # concentration: how many DISTINCT targets carry the panel operator's successes?
    hits = {}
    for s in S:
        for t in IDS:
            if PA[s].get(t, 0):
                hits.setdefault(t, []).append(s)
    tot = sum(len(v) for v in hits.values())
    print(f"  panel-operator successes: {tot} target-seed hits on {len(hits)} distinct targets "
          f"(of {len(IDS)}); {sum(1 for v in hits.values() if len(v) >= 3)} targets hit in >=3/5 seeds")
    order = sorted(hits.items(), key=lambda kv: -len(kv[1]))
    print("  per-target hit counts (target: seeds): " +
          ", ".join(f"{t.split(':')[1]}:{len(v)}" for t, v in order))
    top = sum(len(v) for _, v in order[:3])
    print(f"  top-3 targets account for {top}/{tot} = {top/tot:.0%} of all successes")

    # are the successes on structurally easy targets? (crossing-pair count from the sweep rows)
    g = {}
    for s in (3, 4):
        for r in json.load(open(os.path.join(HERE, f"seed{s}/sweep.json")))["rows"]:
            g[r["id"]] = r.get("n_pk_pairs")
    gh = [g[t] for t in hits if g.get(t) is not None]
    ga = [v for v in g.values() if v is not None]
    if gh and ga:
        print(f"  crossing-pair count: successes mean {sum(gh)/len(gh):.2f} vs pool mean {sum(ga)/len(ga):.2f} "
              f"(lower = successes sit on structurally simpler targets)")


if __name__ == "__main__":
    try:
        matched_seed_paired()
        two_way_bootstrap()
        influence_and_concentration()
    except Exception as e:
        print("  (matched-seed section skipped:", repr(e)[:100], ")")
